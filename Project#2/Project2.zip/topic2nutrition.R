plot(NUTRITION$sugars, NUTRITION$rating)

rating <- NUTRITION$rating
sugars <- NUTRITION$sugars

#linear model
cor(NUTRITION$rating, NUTRITION$sugars)
linearModel <- lm(formula = rating ~ sugars, data = NUTRITION)
summary(linearModel)

#quadratic fit
sugars2 <- sugars^2
twodegree <- lm(rating ~ sugars + sugars2)
summary(twodegree)


